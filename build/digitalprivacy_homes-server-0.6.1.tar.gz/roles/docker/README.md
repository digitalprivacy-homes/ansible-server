# docker
This role adds the Docker repository to sources.list.d/docker.sources and then installs docker.

For more information visit:  
[https://docs.docker.com/engine/install/debian/](https://docs.docker.com/engine/install/debian/)

# Role variables
No variables included in this role.   
Well, there is one “ansible_default_ipv4.address”, but this cannot or should not be changed.