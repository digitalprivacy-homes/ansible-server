# wg-easy
This role installs wg-easy, which is an easy way to use wireguard (VPN). 

For more information visit:  
[https://github.com/wg-easy/wg-easy](https://github.com/wg-easy/wg-easy)

# Role variables
No variables included in this role.