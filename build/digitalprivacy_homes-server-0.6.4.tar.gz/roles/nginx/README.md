# nginx
This role installs nginx (and brotli), which is used to serve your services.

For more information visit:  
[https://nginx.org/](https://nginx.org/)

# Role variables
No variables included in this role.   