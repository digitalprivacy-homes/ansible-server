# nextcloud
This role installs nextcloud, which acts as your cloud storage. It also has way more options to work with.

For more information visit:  
[https://nextcloud.com/](https://nextcloud.com/)

# Role variables
No variables included in this role.  
Well, there is one “ansible_hostname”, which is simply the name of your server (digitalprivacy.homes), which is necessary to achieve a correct description when you receive an e-mail, for example. The hostname is in the subject line.
