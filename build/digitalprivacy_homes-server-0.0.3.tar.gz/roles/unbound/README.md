# unbound
This role installs unbound, which is used in combination with AdGuardHome to act as your local DNS server.

For more information visit:  
[https://nlnetlabs.nl/projects/unbound/about/](https://nlnetlabs.nl/projects/unbound/about/)

# Role variables
No variables included in this role.  