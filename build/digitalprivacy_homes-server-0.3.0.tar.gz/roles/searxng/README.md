# searxng
This role installs searxng, which is used to provide a metasearch engine which aggregates results from up to 245 search services.

For more information visit:  
[https://docs.searxng.org/](https://docs.searxng.org/)

# Role variables
No variables included in this role.  
Well, there is one “ansible_hostname”, which is simply the name of your server (digitalprivacy.homes), which is necessary to achieve a correct description when you receive an e-mail, for example. The hostname is in the subject line.