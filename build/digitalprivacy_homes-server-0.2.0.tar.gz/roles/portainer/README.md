# portainer
This role installs portainer, which is used for to administrate your docker containers (some services).

For more information visit:  
[https://www.portainer.io/](https://www.portainer.io/)

# Role variables
No variables included in this role.  
Well, there is one “ansible_hostname”, which is simply the name of your server (digitalprivacy.homes), which is necessary to achieve a correct description when you receive an e-mail, for example. The hostname is in the subject line.