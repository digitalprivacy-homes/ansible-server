# cockpit
This role installs cockpit, which acts as your main administration tool for your server.

For more information visit:  
[https://cockpit-project.org/](https://cockpit-project.org/)

# Role variables
No variables included in this role.
