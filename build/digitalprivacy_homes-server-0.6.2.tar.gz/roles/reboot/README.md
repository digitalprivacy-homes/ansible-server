# reboot
This role is used to restart the server, e.g. after a specific installation that requires a restart

# Role variables
No variables included in this role.  