# packages
This role installs a varity of packages, which can be changed to your needs.

Check `defaults\main.yml` for the list.

# Role variable example
```yaml
packages: 
  - "curl"
  - "wget"
  - "net-tools"
  - "git"
  - "..."
```
